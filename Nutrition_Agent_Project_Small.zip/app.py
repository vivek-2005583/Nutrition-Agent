import json
import os
from typing import Any, Dict, Optional, Tuple

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request

load_dotenv()

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "nutrition-agent-default-secret")

AGENT_INSTRUCTIONS = """
AGENT_INSTRUCTIONS:
- You are a friendly, evidence-informed nutrition coach and wellness planner.
- Tone: warm, motivating, concise, and practical.
- Specialization: balanced nutrition, weight management, family wellness, Indian diets, vegetarian and non-vegetarian goals, athletic support, diabetes-friendly eating, and child/adult nutrition.
- Safety rules:
  - Do not diagnose medical conditions.
  - Suggest general wellness advice and encourage professional medical care for persistent symptoms.
  - Avoid unsafe fasting or extreme restriction advice.
  - Encourage hydration, fiber, protein, and balanced meals.
  - Respect allergies, medical conditions, and cultural food preferences.
- Indian food preferences:
  - Prioritize familiar Indian foods such as dal, paneer, curd, poha, idli, dosa, chapati, roti, rice, khichdi, vegetables, sprouts, nuts, fruits, oats, lentils, chana, and seasonal produce.
  - Recommend healthier cooking methods: steaming, baking, grilling, sautéing, and air-frying.
  - Suggest lower-sugar and lower-oil alternatives for common Indian snacks and meals.
- Output pattern:
  1. Brief assessment
  2. Personalized calorie guidance
  3. 3-5 meal suggestions
  4. Hydration and habit reminders
  5. A short safety note if needed
- Keep recommendations actionable, family-friendly, and culturally relevant.
"""


def get_default_profile() -> Dict[str, Any]:
    return {
        "name": "Aarav",
        "age": 29,
        "gender": "male",
        "weight_kg": 72,
        "height_cm": 176,
        "goal": "Lose fat and improve energy",
        "activity": "moderately active",
        "diet_type": "vegetarian",
        "calories_target": 2200,
        "preferences": ["Indian", "high-protein", "low-sugar"],
        "family": [
            {"name": "Priya", "age": 27, "goal": "Weight maintenance", "diet_type": "vegetarian"},
            {"name": "Aanya", "age": 8, "goal": "Growth and focus", "diet_type": "vegetarian"},
            {"name": "Rohan", "age": 52, "goal": "Heart health", "diet_type": "non-vegetarian"},
        ],
    }


def bmi_calculator(weight_kg: float, height_cm: float) -> Tuple[float, str, str]:
    height_m = height_cm / 100
    bmi = weight_kg / (height_m ** 2)

    if bmi < 18.5:
        category = "Underweight"
        advice = "Focus on calorie-dense, nutrient-rich meals with protein, healthy fats, and regular meals."
    elif bmi < 25:
        category = "Healthy"
        advice = "You are in a healthy range. Maintain your routine with balanced meals and consistent activity."
    elif bmi < 30:
        category = "Overweight"
        advice = "Aim for portion control, more fiber, and daily movement. Prioritize protein and vegetables."
    else:
        category = "Obese"
        advice = "Consider a gradual approach with structured meal planning, strength training, and professional guidance if needed."

    return bmi, category, advice


def get_watsonx_model():
    api_key = os.getenv("IBM_API_KEY")
    url = os.getenv("IBM_WATSONX_URL")
    project_id = os.getenv("IBM_PROJECT_ID")
    model_id = os.getenv("IBM_MODEL_ID", "ibm/granite-3-8b-instruct")

    if not api_key or not url or not project_id:
        return None

    try:
        from ibm_watsonx_ai import Credentials
        from ibm_watsonx_ai.foundation_models import ModelInference

        credentials = Credentials(url=url, api_key=api_key)
        model = ModelInference(
            model_id=model_id,
            credentials=credentials,
            project_id=project_id,
            params={"max_new_tokens": 500, "temperature": 0.3},
        )
        return model
    except Exception as exc:  # pragma: no cover
        app.logger.warning("IBM Watsonx unavailable: %s", exc)
        return None


def extract_text_response(response: Any) -> str:
    if response is None:
        return ""

    if isinstance(response, str):
        return response.strip()

    if isinstance(response, list):
        if not response:
            return ""
        return extract_text_response(response[0])

    if isinstance(response, dict):
        for key in ("generated_text", "output_text", "text", "completion"):
            if key in response:
                return str(response[key]).strip()

        if "results" in response and isinstance(response["results"], list):
            result = response["results"][0]
            return extract_text_response(result)

        if "choices" in response and isinstance(response["choices"], list):
            first_choice = response["choices"][0]
            if isinstance(first_choice, dict):
                if "message" in first_choice and isinstance(first_choice["message"], dict):
                    return str(first_choice["message"].get("content", "")).strip()
                if "text" in first_choice:
                    return str(first_choice["text"]).strip()

    return str(response).strip()


def build_agent_prompt(message: str, profile: Dict[str, Any]) -> str:
    profile_json = json.dumps(profile, indent=2, ensure_ascii=False)
    return f"""{AGENT_INSTRUCTIONS}

USER PROFILE:
{profile_json}

USER QUESTION:
{message}

Respond in a helpful, practical, and encouraging tone. Include clear recommendations and Indian food examples where relevant.
"""


def generate_local_nutrition_reply(message: str, profile: Dict[str, Any]) -> str:
    goal = str(profile.get("goal", "wellness")).lower()
    diet_type = profile.get("diet_type", "balanced")
    calories = int(profile.get("calories_target", 2200))
    activity = profile.get("activity", "moderately active")

    protein_goal = max(70, int(calories * 0.22 / 4))
    carb_goal = max(180, int(calories * 0.45 / 4))
    fat_goal = max(45, int(calories * 0.25 / 9))

    msg = message.lower()

    if "bmi" in msg:
        bmi, category, advice = bmi_calculator(float(profile.get("weight_kg", 70)), float(profile.get("height_cm", 170)))
        return (
            f"Your BMI is {bmi:.1f}, which falls in the {category} range.\n\n"
            f"{advice}\n\n"
            f"Recommended next step: focus on balanced meals, 25-30g fiber/day, and 7,500-10,000 steps if suitable for your routine."
        )

    if any(word in msg for word in ["weight loss", "lose", "fat", "reduce"]):
        focus = "A sustainable weight-loss plan with protein, fiber, and portion control."
    elif any(word in msg for word in ["gain", "muscle", "bulk", "strength"]):
        focus = "A protein-rich growth plan with adequate calories and strength training support."
    else:
        focus = "A balanced maintenance plan that supports energy, health, and satiety."

    meal_ideas = [
        "Breakfast: 2 roti + sabzi + curd + fruit",
        "Lunch: dal + brown rice + seasonal vegetable + salad",
        "Snack: roasted chana or sprouts with lemon and chaat masala",
        "Dinner: khichdi or paneer tofu bowl with vegetables",
    ]

    return (
        f"Quick assessment: {focus}\n\n"
        f"For a {diet_type} diet, your target is around {calories} kcal/day with a roughly {protein_goal}g protein, {carb_goal}g carbs, and {fat_goal}g healthy fats base.\n\n"
        f"Suggested meals:\n- {meal_ideas[0]}\n- {meal_ideas[1]}\n- {meal_ideas[2]}\n- {meal_ideas[3]}\n\n"
        f"Daily habits: hydrate well, prioritize vegetables and protein at each meal, avoid sugary drinks, and keep a 1-2 tablespoon oil limit for cooking.\n\n"
        f"For the goal '{goal}' and an {activity} routine, a steady rhythm with 3 main meals and 1-2 smart snacks is the most sustainable approach."
    )


def generate_nutrition_reply(message: str, profile: Dict[str, Any]) -> str:
    model = get_watsonx_model()

    if model is not None:
        try:
            prompt = build_agent_prompt(message, profile)
            response = model.generate_text(prompt=prompt)
            text = extract_text_response(response)
            if text:
                return text
        except Exception as exc:  # pragma: no cover
            app.logger.exception("Watsonx generation failed: %s", exc)

    return generate_local_nutrition_reply(message, profile)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/chat", methods=["POST"])
def api_chat():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    profile = data.get("profile") or get_default_profile()

    if not message:
        return jsonify({"reply": "Please ask a nutrition question so I can help you plan better."})

    reply = generate_nutrition_reply(message, profile)
    return jsonify({"reply": reply})


@app.route("/api/bmi", methods=["POST"])
def api_bmi():
    data = request.get_json(silent=True) or {}
    weight = float(data.get("weight", 0) or 0)
    height = float(data.get("height", 0) or 0)

    if weight <= 0 or height <= 0:
        return jsonify({"error": "Enter valid weight and height values."}), 400

    bmi, category, advice = bmi_calculator(weight, height)
    return jsonify({
        "bmi": round(bmi, 1),
        "category": category,
        "advice": advice,
    })


@app.route("/api/meal-plan", methods=["POST"])
def api_meal_plan():
    data = request.get_json(silent=True) or {}
    goal = (data.get("goal") or "maintain weight").lower()
    calories = int(data.get("calories") or 2200)
    diet_type = (data.get("diet_type") or "vegetarian").lower()

    if "lose" in goal or "fat" in goal:
        calorie_target = max(1500, calories - 300)
        focus = " calorie deficit with high fiber and protein"
    elif "gain" in goal or "muscle" in goal:
        calorie_target = calories + 250
        focus = " extra energy and strength support"
    else:
        calorie_target = calories
        focus = " balanced maintenance"

    if "non" in diet_type:
        protein_source = "chicken, fish, eggs, paneer"
    else:
        protein_source = "dal, paneer, tofu, curd, lentils, soy"

    plan = {
        "calorie_target": calorie_target,
        "goal": goal,
        "focus": focus,
        "breakfast": "Oats with nuts, curd, and seasonal fruit or poha with vegetables and sprouts",
        "lunch": "Dal, brown rice, salad, and a vegetable sabzi with a small roti",
        "snack": "Roasted chana, fruit, or a protein smoothie with whey/soy",
        "dinner": "Khichdi, paneer/tofu curry, soup, or grilled vegetables with quinoa or chapati",
        "protein_sources": protein_source,
        "tips": [
            "Keep 1-2 liters of water per day, adjusted for your routine.",
            "Limit fried snacks and sweetened beverages.",
            "Build meals around protein + fiber + vegetables."
        ],
    }

    return jsonify(plan)


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    debug_mode = os.getenv("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug_mode)
