const themeToggle = document.getElementById('themeToggle');
const body = document.body;

if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    const icon = themeToggle.querySelector('i');
    icon.classList.toggle('fa-moon');
    icon.classList.toggle('fa-sun');
  });
}

async function sendChatMessage(message) {
  const chatMessages = document.getElementById('chatMessages');
  const userMessage = document.createElement('div');
  userMessage.className = 'message user-message';
  userMessage.textContent = message;
  chatMessages.appendChild(userMessage);

  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message,
      profile: {
        name: 'Aarav',
        age: 29,
        gender: 'male',
        weight_kg: 72,
        height_cm: 176,
        goal: 'Lose fat and improve energy',
        activity: 'moderately active',
        diet_type: 'vegetarian',
        calories_target: 2200,
      },
    }),
  });

  const data = await response.json();
  const botMessage = document.createElement('div');
  botMessage.className = 'message bot-message';
  botMessage.textContent = data.reply || 'I am preparing a nutrition suggestion for you.';
  chatMessages.appendChild(botMessage);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

const chatForm = document.getElementById('chatForm');
if (chatForm) {
  chatForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    if (!message) return;
    input.value = '';
    await sendChatMessage(message);
  });
}

const bmiForm = document.getElementById('bmiForm');
if (bmiForm) {
  bmiForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    const weight = document.getElementById('weight').value;
    const height = document.getElementById('height').value;

    const response = await fetch('/api/bmi', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ weight, height }),
    });

    const data = await response.json();
    document.getElementById('bmiValue').textContent = data.bmi || '0';
    document.getElementById('bmiCategory').textContent = data.category || 'N/A';
    document.getElementById('bmiAdvice').textContent = data.advice || 'Enter correct values.';
    document.getElementById('quickBmi').textContent = data.bmi || '0';
  });
}

const mealPlanButton = document.getElementById('generateMealPlan');
if (mealPlanButton) {
  mealPlanButton.addEventListener('click', async function () {
    const goal = document.getElementById('goalSelect').value;
    const calories = document.getElementById('calorieInput').value || 2200;
    const dietType = document.getElementById('dietSelect').value;

    const response = await fetch('/api/meal-plan', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ goal, calories, diet_type: dietType }),
    });

    const data = await response.json();
    document.getElementById('breakfastMeal').textContent = data.breakfast;
    document.getElementById('lunchMeal').textContent = data.lunch;
    document.getElementById('snackMeal').textContent = data.snack;
    document.getElementById('dinnerMeal').textContent = data.dinner;
    document.getElementById('metricCalories').textContent = `${data.calorie_target} kcal`;
    document.getElementById('quickCalories').textContent = data.calorie_target;
    document.getElementById('metricProtein').textContent = `${Math.max(90, Math.round(data.calorie_target * 0.22 / 4))}g`;
    document.getElementById('metricCarbs').textContent = `${Math.max(180, Math.round(data.calorie_target * 0.45 / 4))}g`;
    document.getElementById('metricFats').textContent = `${Math.max(50, Math.round(data.calorie_target * 0.25 / 9))}g`;
  });
}
