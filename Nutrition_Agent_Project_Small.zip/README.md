# Nutrition Agent

AI-powered nutrition assistant built with Python Flask and IBM Watsonx.ai Granite models.

## Features

- Chat-based nutrition guidance
- Personalized calorie and macro insights
- BMI calculator
- Meal planning for daily goals
- Family profile support
- Indian food-aware nutrition recommendations
- Responsive Bootstrap UI with dark mode

## Setup

1. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Replace placeholder values in `.env` with your IBM Cloud credentials:
   ```env
   IBM_API_KEY=your_ibm_cloud_api_key_here
   IBM_WATSONX_URL=https://us-south.ml.cloud.ibm.com
   IBM_PROJECT_ID=your_watsonx_project_id_here
   IBM_MODEL_ID=ibm/granite-3-8b-instruct
   SECRET_KEY=your_secret_key
   ```
4. Run the app:
   ```bash
   flask --app app run --debug
   ```
   or
   ```bash
   python app.py
   ```

## App URL

Open http://localhost:5000

## Deployment

For production deployment with Gunicorn:

```bash
gunicorn --bind 0.0.0.0:8000 app:app
```

## Notes

- The app uses environment variables and loads them via `.env`.
- If Watsonx credentials are missing or unavailable, the app falls back to a local nutrition engine so the interface still works.
- The `AGENT_INSTRUCTIONS` block is defined in `app.py` so you can tune tone, diet specialization, safety rules, and Indian food preferences easily.
